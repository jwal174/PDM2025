let port;
let writer;
let ledOn = false;
let analogValue = 0;

let toggleButton;

function setup() {
  createCanvas(400, 400);
  background(0);

  let connectButton = createButton("Connect to Arduino");
  connectButton.position(10, height + 10);
  connectButton.mousePressed(connectToSerial);

  toggleButton = createButton("Toggle LED");
  toggleButton.position(150, height + 10);
  toggleButton.mousePressed(toggleLED);
}

function draw() {
  background(map(analogValue, 0, 1023, 0, 255));
}

async function connectToSerial() {
  try {
    port = await navigator.serial.requestPort();
    await port.open({ baudRate: 9600 });

    const decoder = new TextDecoderStream();
    port.readable.pipeTo(decoder.writable);
    const reader = decoder.readable.getReader();

    const encoder = new TextEncoderStream();
    encoder.readable.pipeTo(port.writable);
    writer = encoder.writable.getWriter();

    readSerial(reader);
    console.log("Connected to serial port");
  } catch (err) {
    console.error("Serial connection error:", err);
  }
}

async function readSerial(reader) {
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    if (value) {
      const trimmed = value.trim();
      const num = parseInt(trimmed);
      if (!isNaN(num)) {
        analogValue = num;
      }
    }
  }
}

function toggleLED() {
  if (writer) {
    ledOn = !ledOn;
    const command = ledOn ? "H" : "L";
    writer.write(command);
    console.log("Sent:", command);
  } else {
    console.log("Writer not ready");
  }
}
